#include <stdio.h>
#include <stdlib.h>
#define arraySize 50
#define seed 3261
void randperm(int a[], int n);
int checkboard(int b[], int n);
int displayboard(int c[], int n);

int main()
{

    int n, myArray[arraySize], idx, repeatTimes, runTime = 0, min, max, sum, location = 0, minArray[arraySize], maxArray[arraySize], p, q, startPoint, numOfElement = 0;
    double meanArray[arraySize], sizeArray[arraySize], sizeFac[arraySize], powResult, facResult;

    srand(seed);

    for (n = 4; n < 21; n++)
    {
        min = 99999;
        max = 0;
        sum = 0;
        powResult = 1.0;
        facResult = 1.0;
        for (idx = 0; idx < n; idx++)
        {
            myArray[idx] = idx;
        }
        runTime = 0;
        do
        {
            repeatTimes = 0;
            do
            {
                randperm(myArray, n);
                repeatTimes++;

            } while (checkboard(myArray, n) == 0);
            sum += repeatTimes;

            runTime++;
            if (min > repeatTimes)
            {
                min = repeatTimes;
            }
            if (max < repeatTimes)
            {
                max = repeatTimes;
            }
            if (runTime == 1)
            {
                printf("This is the first success board for %d x %d size: \n", n, n);
                displayboard(myArray, n);
            }
        } while (runTime < 10);
        maxArray[location] = max;
        minArray[location] = min;
        meanArray[location] = sum / 10;
        for (p = 1; p <= n; p++)
        {
            powResult *= n;
        }
        sizeArray[location] = powResult;
        for (q = 1; q <= n; q++)
        {
            facResult *= q;
        }
        sizeFac[location] = facResult;

        location++;
    }

    printf("This is the statistics with n = 4 - 20 for 10 times:\n");
    printf("size\t min\t max\t mean\t\t size**size\t size!\n");
    for (startPoint = 4; startPoint < 21; startPoint++)
    {
        printf("%d\t %d\t %d\t %.1e\t %.1e\t %.1e\n", startPoint, minArray[numOfElement], maxArray[numOfElement], meanArray[numOfElement], sizeArray[numOfElement], sizeFac[numOfElement]);
        numOfElement++;
    }
    return 0;
}

void randperm(int oriArray[], int value)
{
    int temp, randArray[arraySize], start = 0, ind, index;

    for (ind = 0; ind < value; ind++)
    {
        randArray[ind] = rand() % value;
    }

    for (index = value - 1; index >= 1; index--)
    {
        temp = oriArray[index];
        oriArray[index] = oriArray[randArray[start]];
        oriArray[randArray[start]] = temp;
        start++;
    }
}

int checkboard(int origArray[], int values)
{
    int ifSuccess = 0, index;

    for (index = 0; index < values; index++)
    {
        if (((origArray[index] + 1) == (origArray[index + 1])) || ((origArray[index] - 1) == (origArray[index + 1])))
        {
            ifSuccess = 0;
            break;
        }
        else
        {
            ifSuccess = 1;
        }
    }
    return ifSuccess;
}

int displayboard(int origiArray[], int myValue)
{
    int i, j, k, g, h;
    char myBoard[arraySize][arraySize] = {{'_'}};
    for (j = 0; j < myValue; ++j)
    {
        for (k = 0; k < myValue; ++k)
        {
            myBoard[j][k] = '_';
            myBoard[j][origiArray[j]] = 'Q';
        }
    }
    printf("[ ");
    for (i = 0; i < myValue; i++)
    {
        printf(" %d ", origiArray[i]);
    }
    printf(" ]\n");
    for (g = 0; g < myValue; ++g)
    {
        for (h = 0; h < myValue; ++h)
        {
            printf("%2c", myBoard[g][h]);
        }
        printf("\n");
    }
    return 0;
}